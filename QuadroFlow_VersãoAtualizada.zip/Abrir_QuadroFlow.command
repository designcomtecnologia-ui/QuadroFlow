#!/bin/bash
cd "$(dirname "$0")"
open "QuadroFlow.html"
