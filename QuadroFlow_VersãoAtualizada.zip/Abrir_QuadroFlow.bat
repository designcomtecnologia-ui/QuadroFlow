@echo off
start "" "%~dp0QuadroFlow.html"
