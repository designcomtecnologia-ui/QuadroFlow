# Como usar o QuadroFlow

O QuadroFlow funciona diretamente no computador, sem instalação.

## Para começar

1. Descompacte o arquivo ZIP.
2. Abra a pasta do QuadroFlow.
3. Dê dois cliques em **QuadroFlow.html**.
4. O sistema será aberto no navegador.

> **Importante:** para iniciar o sistema, abra sempre **QuadroFlow.html**. Não use `entregues.html` ou `lixeira.html` para iniciar.

## Criar uma tarefa

Clique em **+ Adicionar post-it** e preencha Cliente, Título, Texto, Prioridade, URLs e arquivos, se necessário. Depois clique em **Salvar**.

## Organizar

Arraste os post-its entre os quadrantes. A cor do post-it acompanha automaticamente o quadrante onde ele estiver.

## Pesquisar

Clique em **Filtro**. O campo único pesquisa simultaneamente cliente, título, texto, prioridade, URLs e arquivos.

## Entregues e lixeira

- `entregues.html`: tarefas que chegaram à etapa **Tarefa entregue** e foram arquivadas.
- `lixeira.html`: tarefas excluídas manualmente, com opção de **Voltar** ou **Excluir** definitivamente.

## Dados locais

As informações ficam armazenadas no navegador. Use sempre o mesmo navegador e evite apagar os dados do site/navegador para não perder as informações locais.
