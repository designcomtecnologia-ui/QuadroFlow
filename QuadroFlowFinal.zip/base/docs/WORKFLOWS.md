# WORKFLOWS — QuadroFlow

## WF-01 — Criar post-it

1. Usuário clica em **Adicionar post-it**.
2. Abrir formulário.
3. Informar Cliente.
4. Informar Título.
5. Informar Texto.
6. Escolher prioridade: Alta, Média ou Baixa.
7. Informar zero ou mais URLs.
8. Selecionar arquivos.
9. Validar título e texto obrigatórios.
10. Criar post-it no quadrante de destino.
11. Calcular cor pelo quadrante.
12. Persistir.
13. Renderizar.

## WF-02 — Ordem e tipografia do post-it

Sempre renderizar:

```text
Cliente
Título
Texto
Prioridade
Miniaturas/Preview
URLs
```

Cliente: 11px light.

Título: 16px medium.

Texto: 13px regular.

## WF-03 — Selecionar prioridade

1. Usuário escolhe uma opção.
2. Alta mostra bolinha vermelha.
3. Média mostra bolinha amarela.
4. Baixa mostra bolinha verde.
5. Apenas uma opção fica selecionada.
6. A prioridade não modifica a cor do quadrante/post-it.

## WF-04 — Visualizar anexo

### Imagem

1. Exibir thumbnail.
2. Usuário clica.
3. Abrir lightbox.
4. Permitir ampliar/fechar.

### Vídeo

1. Exibir thumbnail.
2. Usuário clica.
3. Abrir player com controles.

### PDF

1. Exibir thumbnail/identificador.
2. Usuário clica.
3. Abrir preview embutido.

### DOC/DOCX

1. Exibir miniatura com identificação do formato.
2. Usuário clica.
3. Processar client-side.
4. Abrir visualização dentro do QuadroFlow.

### XLS/XLSX

1. Exibir miniatura com identificação do formato.
2. Usuário clica.
3. Ler client-side.
4. Mostrar planilha em modo de visualização.

## WF-05 — Múltiplas URLs

1. Usuário informa uma URL por linha.
2. Sistema valida cada linha.
3. Salva em `urls[]`.
4. Renderiza todas as URLs no post-it.
5. Mantém os links também em tarefas arquivadas.

## WF-06 — Mover post-it entre quadrantes

1. Iniciar drag.
2. Identificar origem.
3. Identificar destino.
4. Remover da origem.
5. Inserir no destino.
6. Recalcular cor pelo destino imediatamente.
7. Se destino = Tarefa entregue, registrar `deliveredAt` e prazo de 2 dias.
8. Se sair de Tarefa entregue, remover dados de expiração quando aplicável.
9. Persistir.
10. Renderizar.

**Regra crítica:** o post-it nunca leva sua cor antiga para o destino.

## WF-07 — Restaurar da lixeira

1. Usuário abre `lixeira.html`.
2. Escolhe **Voltar**.
3. Sistema procura o quadrante de origem.
4. Restaura o post-it.
5. Recalcula sua cor pelo quadrante restaurado.
6. Remove metadados de lixeira.
7. Persiste.

Se a origem não existir, a versão atual pode usar um fallback definido pelo produto, mas nunca deve reaproveitar a cor antiga do post-it como verdade.

## WF-08 — Enviar manualmente para lixeira

1. No item de Tarefa entregue, usuário clica na lixeira do próprio post-it.
2. Exibir confirmação.
3. Confirmando, remover do quadro.
4. Inserir em `trash`.
5. Gravar origem e data.
6. Persistir.
7. Atualizar a tela.

## WF-09 — Arquivar automaticamente tarefa entregue

1. Post-it entra em Tarefa entregue.
2. Registrar `deliveredAt`.
3. Definir `deliveryDue = deliveredAt + 2 dias`.
4. O sistema verifica tarefas vencidas.
5. Quando vencer, mover de `state` para `delivered`.
6. Gravar `archivedAt`.
7. Preservar cliente, título, texto, prioridade, anexos, URLs, datas e origem.
8. Persistir.
9. A tarefa passa a aparecer em **Tarefas Entregues**.

**Nunca enviar automaticamente para a lixeira.**

## WF-10 — Abrir Tarefas Entregues

1. Usuário acessa `entregues.html`.
2. Página lê o mesmo armazenamento local.
3. Exibe tarefas arquivadas.
4. Mantém filtros e visualização dos anexos.
5. Permite abrir previews sem retornar automaticamente ao quadro.

## WF-11 — Filtrar

1. Usuário informa termo e/ou datas.
2. Clica em **Filtrar**.
3. Sistema pesquisa tarefas ativas e arquivadas.
4. Procura em Cliente, Título, Texto, Prioridade, URLs e nomes de arquivos.
5. Exibe apenas correspondências.
6. Atualiza navegação.

## WF-12 — Limpar filtro

1. Usuário clica **Limpar**.
2. Campos são zerados.
3. Toda a lista volta a aparecer.

## WF-13 — Novo quadrante

1. Usuário escolhe Novo quadrante.
2. Informar nome.
3. Sistema escolhe a primeira cor disponível que não esteja em uso.
4. Inserir entre Tarefas e Tarefa entregue.
5. Permitir posterior reordenação.

## WF-14 — Reordenar quadrantes

1. Usuário arrasta quadrante customizado.
2. Sistema identifica origem/destino.
3. Tarefas não pode deixar a primeira posição.
4. Tarefa entregue não pode deixar a última posição.
5. Persistir ordem.

## WF-15 — Scroll horizontal

### Até quatro quadrantes

- ocupar largura disponível;
- não exigir scroll horizontal.

### Cinco ou mais

- fixar largura dos quadrantes;
- ativar overflow horizontal;
- manter scroll por mouse e trackpad;
- mostrar setas.

### Setas

1. Clicar `←` ou `→`.
2. Calcular aproximadamente uma coluna + gap.
3. Executar `scrollBy({behavior:'smooth'})`.
4. Atualizar estado das setas.

## WF-16 — Menu mobile

1. Manter **Adicionar post-it** visível.
2. Manter menu hambúrguer.
3. Colocar os demais comandos no menu.
4. Clicar fora fecha o menu.

## WF-17 — Salvar

1. Usuário clica Salvar.
2. Serializar estado.
3. Persistir `state`, `delivered` e `trash`.
4. Exibir “Salvo com sucesso”.

## WF-18 — Carregar

1. Usuário clica Carregar.
2. Ler armazenamento.
3. Validar estruturas.
4. Corrigir dados legados.
5. Recalcular cores dos post-its pelo quadrante.
6. Verificar tarefas entregues vencidas.
7. Arquivar as que passaram de 2 dias.
8. Renderizar.

## WF-19 — Regra de ouro da cor

```text
QUALQUER OPERAÇÃO
        ↓
identificar quadrante atual
        ↓
colorForColumn(quadrante)
        ↓
atualizar fundo visual
        ↓
persistir dado derivado, se necessário
```

Não deve existir um fluxo onde a cor antiga do post-it tenha prioridade sobre o quadrante atual.

## WF-20 — Qualidade antes do ZIP

Executar obrigatoriamente:

1. `node --check`;
2. integridade do ZIP;
3. criação/edição;
4. drag entre quadrantes;
5. restauração;
6. filtro de tarefa ativa;
7. filtro de tarefa arquivada;
8. preview de imagem/vídeo/PDF;
9. preview de Word/Excel;
10. persistência;
11. arquivamento em 2 dias;
12. scroll com 5+ quadrantes.


## Performance e armazenamento — versão ajustada

O QuadroFlow deve responder imediatamente a ações locais comuns. O quadro não deve reconstruir todos os post-its quando uma única tarefa for alterada. A renderização deve ser incremental sempre que a operação permitir.

Anexos binários (imagens, vídeos, PDF, DOC/DOCX e XLS/XLSX) são armazenados em IndexedDB. O localStorage fica reservado para estado leve: quadrantes, tarefas, textos, prioridade, URLs e metadados dos anexos. Dados antigos em Base64 são migrados para IndexedDB na primeira abertura da versão ajustada.

A persistência é agrupada/debounced para evitar gravações repetidas durante operações rápidas, mantendo o botão Salvar como persistência imediata.

Filtros devem ocultar/mostrar tarefas já renderizadas, evitando reconstrução integral do DOM.
