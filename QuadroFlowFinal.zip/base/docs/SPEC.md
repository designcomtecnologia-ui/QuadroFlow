# SPEC — QuadroFlow

## 1. Modelo de dados

```js
{
  state: [
    {
      id,
      title,
      status,
      color,
      notes: [
        {
          id,
          client,
          title,
          text,
          priority: 'Alta' | 'Média' | 'Baixa' | '',
          urls: [],
          attachments: [],
          createdAt,
          deliveredAt,
          deliveryDue
        }
      ]
    }
  ],
  delivered: [
    {
      ...note,
      deliveredAt,
      archivedAt,
      originColumnId,
      originColumnTitle
    }
  ],
  trash: [
    {
      ...note,
      trashAt,
      fromColumnId,
      fromColumnTitle
    }
  ]
}
```

## 2. Post-it: apresentação

### CSS canônico

```css
.note-client {
  font-size: 11px;
  font-weight: 300;
}

.note-title {
  font-size: 16px;
  font-weight: 500;
}

.note-text {
  font-size: 13px;
  font-weight: 400;
}
```

### Prioridade

```text
Alta  = #E53935
Média = #F2C94C
Baixa = #34A853
```

A bolinha fica no topo do conteúdo do post-it. Ela não altera a cor do fundo.

## 3. Formulário

Campos, na ordem:

```text
Cliente
Título
Texto
Prioridade
URLs
Escolher arquivos
```

Não criar inputs de `project` ou `tags`.

## 4. Anexos

Estrutura recomendada:

```js
{
  id,
  name,
  type,
  size,
  data,
  createdAt
}
```

Tipos mínimos:

```text
image/*
video/*
application/pdf
.doc/.docx
.xls/.xlsx
```

### Estratégia de visualização

**Imagem:** `<img>` + lightbox.

**Vídeo:** `<video controls>` + player.

**PDF:** `<iframe>`/visualizador PDF embutido.

**DOCX:** renderização client-side usando biblioteca empacotada, por exemplo conversão para HTML.

**XLSX:** leitura client-side e apresentação em tabela/preview.

**DOC/XLS legados:** tentar processamento client-side compatível; se o navegador não puder representar o formato original diretamente, usar conversão/extração local antes da visualização. A aplicação não deve tratar “download” como única experiência de arquivo.

## 5. URLs

```js
urls: ['https://site1.com', 'https://site2.com']
```

Validação mínima: cada item deve começar por `http://` ou `https://`.

## 6. Cores dos quadrantes

```js
const FIXED_COLORS = {
  todo: '#F6E7A8',
  start: '#CFE5C5',
  production: '#C9DDE8',
  done: '#EBC9D0',
  delivered: '#DCCFED'
};

function colorForColumn(column) {
  return FIXED_COLORS[column.status] || column.color;
}
```

## 7. Regra técnica de cor

A função acima é a única fonte visual para o fundo do post-it.

```js
function syncNoteColor(note, column) {
  note.color = colorForColumn(column); // dado derivado
}
```

Nunca:

```js
note.color // como fonte visual independente
```

Ao renderizar:

```js
element.style.backgroundColor = colorForColumn(currentColumn);
```

## 8. Movimentação

Fluxo:

```text
origem
  ↓
remover da origem
  ↓
adicionar no destino
  ↓
syncNoteColor(note, destino)
  ↓
se destino = delivered → calcular deliveredAt/deliveryDue
  ↓
render
  ↓
persist
```

## 9. Restauração

Ao restaurar da lixeira:

1. localizar o quadrante de origem;
2. inserir a tarefa nele;
3. recalcular a cor com `colorForColumn()`;
4. remover metadados de lixeira;
5. persistir.

## 10. Arquivamento automático

Ao entrar em `Tarefa entregue`:

```js
note.deliveredAt = now;
note.deliveryDue = addDays(now, 2);
```

Ao atingir o prazo:

```text
Tarefa entregue
      ↓
Tarefas Entregues
```

Não enviar para `trash`.

A página recomendada é:

```text
entregues.html
```

## 11. Filtro

O mecanismo de busca deve operar sobre:

```js
searchable = [
  note.client,
  note.title,
  note.text,
  note.priority,
  ...(note.urls || []),
  ...(note.attachments || []).map(a => a.name)
]
```

O conjunto pesquisado deve incluir:

- tarefas ativas;
- tarefas de Tarefa entregue, antes do arquivamento;
- tarefas arquivadas em `delivered`.

## 12. Lixeira

Arquivo:

```text
lixeira.html
```

Ações por item:

```text
Voltar | Excluir
```

`Voltar` restaura para a origem quando ela existir. A cor deve ser recalculada.

## 13. Layout

Até quatro:

```css
.board {
  display: flex;
}
.column {
  flex: 1 1 0;
  min-width: 0;
}
```

A partir de cinco:

```css
.board {
  overflow-x: auto;
}
.column {
  flex: 0 0 310px;
  width: 310px;
  min-width: 310px;
}
```

## 14. Navegação

IDs:

```text
#navLeft
#navRight
```

Com overflow:

- mostrar setas;
- desabilitar no limite;
- usar `scrollBy()` aproximadamente uma coluna + gap.

Scrollbar pode ser visualmente discreta/camuflada, mas não pode bloquear o scroll.

## 15. Compatibilidade

A aplicação deve funcionar em navegadores modernos com suporte a JavaScript, localStorage, drag-and-drop e APIs necessárias para arquivos e mídia.

Para preview avançado de DOCX/XLSX, as bibliotecas necessárias devem ser incluídas no pacote, evitando dependência obrigatória de servidor.

## 16. Qualidade

Antes da entrega:

- `node --check` no JavaScript;
- `ZipFile.testzip()` no pacote;
- testar criação/edição/movimentação/restauração;
- testar filtro em tarefa ativa e arquivada;
- testar preview de imagem, vídeo e PDF;
- testar DOC/DOCX e XLS/XLSX com arquivos reais;
- testar cinco ou mais quadrantes;
- testar persistência após recarregar;
- confirmar que Tarefa entregue é lilás em todas as situações.


## Performance e armazenamento — versão ajustada

O QuadroFlow deve responder imediatamente a ações locais comuns. O quadro não deve reconstruir todos os post-its quando uma única tarefa for alterada. A renderização deve ser incremental sempre que a operação permitir.

Anexos binários (imagens, vídeos, PDF, DOC/DOCX e XLS/XLSX) são armazenados em IndexedDB. O localStorage fica reservado para estado leve: quadrantes, tarefas, textos, prioridade, URLs e metadados dos anexos. Dados antigos em Base64 são migrados para IndexedDB na primeira abertura da versão ajustada.

A persistência é agrupada/debounced para evitar gravações repetidas durante operações rápidas, mantendo o botão Salvar como persistência imediata.

Filtros devem ocultar/mostrar tarefas já renderizadas, evitando reconstrução integral do DOM.
