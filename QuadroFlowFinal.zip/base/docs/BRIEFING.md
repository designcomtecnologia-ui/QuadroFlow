# BRIEFING — QuadroFlow

## 1. Visão do produto

O **QuadroFlow** é uma ferramenta visual de gestão de tarefas baseada em Kanban e post-its. A versão atual é **local-first**, sem servidor obrigatório, com persistência no navegador, e foi pensada para distribuição simples e gratuita.

A evolução do produto prevê uma arquitetura SaaS multiusuário, mas este briefing consolida primeiro as regras funcionais e visuais da versão atual.

## 2. Princípios

- **Visual-first:** o estado é percebido rapidamente pelo quadrante e sua cor.
- **Baixo atrito:** criar e acompanhar uma tarefa deve ser rápido.
- **Cor contextual:** o post-it nunca decide sua própria cor; a cor vem do quadrante atual.
- **Recuperabilidade:** exclusão e arquivamento são operações diferentes.
- **Visualização real:** anexos não devem existir apenas como download; precisam ter preview quando tecnicamente possível.
- **Responsividade real:** até quatro quadrantes ocupam a área disponível; cinco ou mais ativam scroll horizontal sem encolher os quadrantes.

## 3. Fluxo padrão

1. **Tarefas** — `#F6E7A8`
2. **Iniciar as tarefas** — `#CFE5C5`
3. **Tarefa em produção** — `#C9DDE8`
4. **Tarefa resolvida** — `#EBC9D0`
5. **Tarefa entregue** — `#DCCFED`

**Tarefas** permanece primeiro e **Tarefa entregue** permanece por último. Quadrantes customizados ficam entre os extremos e recebem cores únicas, sem repetição.

## 4. Regra absoluta de cores

A cor visual do post-it é sempre derivada do quadrante onde ele está.

Isso vale para:

- criação;
- edição;
- movimentação entre quadrantes;
- reordenação dentro do quadrante;
- restauração da lixeira;
- carregamento de dados antigos;
- renderização;
- arquivamento em Tarefas Entregues e posterior consulta.

`note.color` pode existir apenas como dado derivado/compatibilidade. Nunca pode ser a fonte visual de verdade.

## 5. Hierarquia visual do post-it

A ordem oficial é:

1. **Cliente** — 11px, light (`font-weight: 300`)
2. **Título** — 16px, medium (`font-weight: 500`)
3. **Texto** — 13px, regular (`font-weight: 400`)
4. **Prioridade** — bolinha colorida no topo do post-it
5. **Miniaturas/visualização de anexos**
6. **URLs**

### Prioridade

- **Alta:** bolinha vermelha
- **Média:** bolinha amarela
- **Baixa:** bolinha verde

A prioridade é um atributo da tarefa e não deve alterar a cor do fundo do post-it, que continua sendo determinada pelo quadrante.

## 6. Formulário “Adicionar post-it”

O formulário deve conter somente:

1. Cliente
2. Título
3. Texto
4. Prioridade
5. URLs
6. Escolher arquivos

**Projeto e Tags não fazem parte do formulário desta versão e devem ser removidos.**

O botão **Salvar** usa o azul da marca do QuadroFlow: `#28A5C6`.

### Arquivos aceitos

- imagens;
- vídeos;
- PDF;
- Word (`.doc`, `.docx`);
- Excel (`.xls`, `.xlsx`).

## 7. Visualização dos anexos

Anexar arquivo sem permitir visualização não atende ao objetivo do produto.

- Imagem: miniatura + zoom/lightbox.
- Vídeo: miniatura + player no visualizador.
- PDF: visualização embutida.
- DOC/DOCX: visualização no próprio sistema através de mecanismo client-side adequado.
- XLS/XLSX: visualização em tabela/preview no próprio sistema através de mecanismo client-side adequado.

Quando o formato não puder ser renderizado de forma confiável, deve existir uma mensagem clara de limitação e ação para abertura/download, mas essa é exceção; o requisito padrão é **preview**.

## 8. URLs

O post-it pode ter múltiplas URLs, uma por linha, e todas devem ser preservadas.

## 9. Entrega, arquivo e lixeira

### Tarefa entregue

Ao entrar no quadrante **Tarefa entregue**, o sistema registra a data de entrega.

Após **2 dias**, a tarefa sai do quadro operacional e vai para a página **Tarefas Entregues** (`entregues.html`).

Ela deve manter:

- cliente;
- título;
- texto;
- prioridade;
- anexos;
- URLs;
- quadrante/projeto de origem quando aplicável;
- data de criação;
- data de entrega;
- demais metadados necessários ao histórico.

### Lixeira

A lixeira é independente da página de entregues e só recebe itens enviados para exclusão manual.

Arquivo: `lixeira.html`.

Cada item deve ter somente:

- **Voltar**;
- **Excluir**.

## 10. Filtro

O filtro deve pesquisar tanto o quadro atual quanto as tarefas arquivadas/entregues.

A busca deve considerar, quando existentes:

- cliente;
- título;
- texto;
- prioridade;
- URLs;
- nome de arquivos;
- tipo de arquivo;
- responsável/usuário nas versões multiusuário;
- projeto/histórico quando esse dado existir em registros legados ou futuros.

O botão **Filtrar** executa a busca e **Limpar** restaura a visão completa.

## 11. Layout e navegação

Até quatro quadrantes: divisão adaptativa da largura.

A partir do quinto: largura fixa dos quadrantes, aproximadamente 310px, e scroll horizontal real.

Navegação por:

- mouse;
- trackpad;
- setas `←` e `→`.

As setas aparecem somente quando existir overflow.

## 12. Distribuição

O pacote deve manter:

- `QuadroFlow.html`;
- página `entregues.html`;
- página `lixeira.html`;
- arquivos JS/dados auxiliares;
- logo;
- ícone;
- manifest;
- launchers Windows, macOS e Linux;
- documentação.


## Performance e armazenamento — versão ajustada

O QuadroFlow deve responder imediatamente a ações locais comuns. O quadro não deve reconstruir todos os post-its quando uma única tarefa for alterada. A renderização deve ser incremental sempre que a operação permitir.

Anexos binários (imagens, vídeos, PDF, DOC/DOCX e XLS/XLSX) são armazenados em IndexedDB. O localStorage fica reservado para estado leve: quadrantes, tarefas, textos, prioridade, URLs e metadados dos anexos. Dados antigos em Base64 são migrados para IndexedDB na primeira abertura da versão ajustada.

A persistência é agrupada/debounced para evitar gravações repetidas durante operações rápidas, mantendo o botão Salvar como persistência imediata.

Filtros devem ocultar/mostrar tarefas já renderizadas, evitando reconstrução integral do DOM.
