# PRD — QuadroFlow

## 1. Objetivo

Entregar uma ferramenta de tarefas visual, simples e confiável, com Kanban, post-its, persistência local, anexos visualizáveis, arquivamento de tarefas entregues e lixeira independente.

## 2. Escopo funcional

### RF-001 — Criar post-it

O usuário deve conseguir criar um post-it informando Cliente, Título, Texto, Prioridade, URLs e arquivos.

Título e texto são obrigatórios. Os demais campos são opcionais.

### RF-002 — Hierarquia visual

A renderização do post-it deve seguir exatamente:

1. Cliente — 11px light;
2. Título — 16px medium;
3. Texto — 13px regular;
4. prioridade por bolinha no topo;
5. miniaturas/preview;
6. URLs.

### RF-003 — Prioridade

O usuário escolhe uma opção:

- Alta — vermelho;
- Média — amarelo;
- Baixa — verde.

Somente uma prioridade por tarefa.

### RF-004 — Remoção de campos

O formulário não deve apresentar Projeto nem Tags.

### RF-005 — Anexos

Aceitar imagens, vídeos, PDF, Word e Excel.

Cada anexo deve apresentar preview compatível com seu formato.

### RF-006 — Preview

- Imagens devem abrir em zoom/lightbox.
- Vídeos devem abrir em player.
- PDFs devem abrir em visualização embutida.
- DOC/DOCX e XLS/XLSX devem ter preview dentro da aplicação usando bibliotecas client-side empacotadas ou mecanismo equivalente.

### RF-007 — URLs

Permitir múltiplas URLs. Cada URL deve ser validada e preservada.

### RF-008 — Cor por quadrante

O post-it herda a cor do quadrante atual.

É proibido utilizar a cor gravada no post-it como fonte visual primária.

### RF-009 — Movimentação

Ao mover um post-it para outro quadrante, a cor deve ser recalculada imediatamente pelo destino.

### RF-010 — Restauração

Ao restaurar da lixeira, a cor deve ser recalculada pelo quadrante restaurado.

### RF-011 — Tarefa entregue

A cor do quadrante é `#DCCFED`.

Ao entrar nesse quadrante, registrar `deliveredAt` e calcular prazo de arquivamento de 2 dias.

### RF-012 — Arquivamento

Depois de 2 dias, a tarefa deve ser transferida para **Tarefas Entregues**, em página própria.

Esse processo não é exclusão e não deve enviar o item para a lixeira.

### RF-013 — Lixeira

A lixeira é uma página própria e recebe itens enviados manualmente para exclusão.

### RF-014 — Lixeira: ações

Cada item deve disponibilizar apenas:

- Voltar;
- Excluir.

### RF-015 — Filtro

A busca deve funcionar no quadro atual e em Tarefas Entregues.

Pesquisar, no mínimo, cliente, título, texto, URLs, nomes de arquivos e prioridade.

### RF-016 — Filtros adicionais

O sistema pode acrescentar data, responsável, projeto/histórico, tipo de arquivo e status nas versões futuras, sem quebrar a busca básica.

### RF-017 — Quadrantes

Permitir criar, renomear, excluir e reordenar quadrantes customizados.

Tarefas permanece primeiro e Tarefa entregue permanece último.

### RF-018 — Cores únicas

Quadrante novo não pode repetir a cor de outro quadrante existente.

### RF-019 — Responsividade

Até quatro quadrantes: largura adaptativa.

Cinco ou mais: largura fixa e overflow horizontal.

### RF-020 — Navegação horizontal

Setas devem controlar o scroll quando houver overflow e mouse/trackpad também devem funcionar.

### RF-021 — Persistência

Salvar em `localStorage` e recuperar o estado após recarregar.

### RF-022 — Identidade

Botão Salvar e ação Adicionar post-it usam o tom de marca azul `#28A5C6`.

## 3. Critérios de aceitação

1. Criar tarefa respeita a nova ordem dos campos.
2. Cliente aparece com 11px light.
3. Título aparece com 16px medium.
4. Texto aparece com 13px regular.
5. Prioridade aparece por bolinha vermelha/amarela/verde.
6. Projeto e Tags não aparecem no formulário.
7. Imagens têm miniatura e zoom.
8. Vídeos têm miniatura e player.
9. PDFs podem ser visualizados sem depender apenas de download.
10. DOC/DOCX e XLS/XLSX possuem mecanismo de preview.
11. Múltiplas URLs são preservadas.
12. Mover/restaurar tarefa recalcula sua cor.
13. Tarefa entregue permanece lilás `#DCCFED`.
14. Após 2 dias, tarefa entregue vai para Tarefas Entregues.
15. Lixeira permanece separada e não é usada para arquivamento automático.
16. Busca encontra tarefas arquivadas.
17. Cinco ou mais quadrantes permitem scroll horizontal sem encolher.


## Performance e armazenamento — versão ajustada

O QuadroFlow deve responder imediatamente a ações locais comuns. O quadro não deve reconstruir todos os post-its quando uma única tarefa for alterada. A renderização deve ser incremental sempre que a operação permitir.

Anexos binários (imagens, vídeos, PDF, DOC/DOCX e XLS/XLSX) são armazenados em IndexedDB. O localStorage fica reservado para estado leve: quadrantes, tarefas, textos, prioridade, URLs e metadados dos anexos. Dados antigos em Base64 são migrados para IndexedDB na primeira abertura da versão ajustada.

A persistência é agrupada/debounced para evitar gravações repetidas durante operações rápidas, mantendo o botão Salvar como persistência imediata.

Filtros devem ocultar/mostrar tarefas já renderizadas, evitando reconstrução integral do DOM.
