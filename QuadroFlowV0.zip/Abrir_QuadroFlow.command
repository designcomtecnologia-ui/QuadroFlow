#!/bin/bash
DIR="$(cd "$(dirname "$0")" && pwd)"
open "$DIR/QuadroFlow.html"
