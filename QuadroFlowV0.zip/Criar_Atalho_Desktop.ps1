$folder=Split-Path -Parent $MyInvocation.MyCommand.Path
$html=Join-Path $folder "QuadroFlow.html"
$icon=Join-Path $folder "QuadroFlow.ico"
$desktop=[Environment]::GetFolderPath("Desktop")
$link=Join-Path $desktop "QuadroFlow.lnk"
$wsh=New-Object -ComObject WScript.Shell
$s=$wsh.CreateShortcut($link)
$s.TargetPath=$html
$s.WorkingDirectory=$folder
$s.IconLocation="$icon,0"
$s.Description="Abrir QuadroFlow"
$s.Save()
