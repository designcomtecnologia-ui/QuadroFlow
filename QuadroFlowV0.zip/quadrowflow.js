const KEY='quadrowflow-final-v6';
const DEFAULT_COLORS={todo:'#F6E7A8',start:'#CFE5C5',production:'#C9DDE8',done:'#EBC9D0',delivered:'#DCCFED'};
const EXTRA_COLORS=['#F4C7AB','#C4D7F2','#D8C6E8','#F2D3B5','#BFDCD3','#E5C1D5','#C8D3E9','#E8D9A8','#D3C4EA','#C7E4DD','#F0C9B6','#D9D0A8','#C5D6E5','#E6CFE0','#D2E2C6'];
let state=[],trash=[],selectedImages=[],returnColumnId=null;

const uid=()=>Date.now().toString(36)+Math.random().toString(36).slice(2);
const esc=s=>String(s??'').replace(/[&<>"']/g,m=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#039;'}[m]));
const date=v=>{const d=new Date(v);return d.toLocaleDateString('pt-BR')+', '+d.toLocaleTimeString('pt-BR',{hour:'2-digit',minute:'2-digit'})};

function defaults(){return[
{id:uid(),title:'Tarefas',status:'todo',color:DEFAULT_COLORS.todo,notes:[]},
{id:uid(),title:'Iniciar as tarefas',status:'start',color:DEFAULT_COLORS.start,notes:[]},
{id:uid(),title:'Tarefa em produção',status:'production',color:DEFAULT_COLORS.production,notes:[]},
{id:uid(),title:'Tarefa resolvida',status:'done',color:DEFAULT_COLORS.done,notes:[]},
{id:uid(),title:'Tarefa entregue',status:'delivered',color:DEFAULT_COLORS.delivered,notes:[]}
]}
function usedColors(){return new Set(state.map(c=>(c.color||'').toLowerCase()).filter(Boolean))}
function nextUniqueColor(){const u=usedColors();const c=EXTRA_COLORS.find(x=>!u.has(x.toLowerCase()));if(c)return c;let i=(state.length*37)%360;while(true){const h=`hsl(${i} 72% 81%)`.toLowerCase();if(!u.has(h))return h;i=(i+47)%360}}
function normalize(){state.forEach(c=>{if(!c.color)c.color=nextUniqueColor();c.notes=(c.notes||[]).map(n=>({...n,color:c.color,images:n.images||[],url:n.url||''}))})}
function toast(t){const x=document.getElementById('toast');x.textContent=t;x.classList.add('show');clearTimeout(window._toast);window._toast=setTimeout(()=>x.classList.remove('show'),1800)}
function persist(){localStorage.setItem(KEY,JSON.stringify({state,trash}))}
function save(){persist();toast('Salvo com sucesso')}
function load(){try{const raw=localStorage.getItem(KEY);if(raw){const o=JSON.parse(raw);state=Array.isArray(o?.state)?o.state:defaults();trash=Array.isArray(o?.trash)?o.trash:[];normalize();render();processDeliveredTimers();return}}catch(e){}state=defaults();trash=[];normalize();render();processDeliveredTimers()}
function closeModal(){document.getElementById('modalBg').classList.remove('show');selectedImages=[]}
function showModal(content){document.getElementById('modal').innerHTML=content;document.getElementById('modalBg').classList.add('show')}
function noteBy(cid,nid){const c=state.find(x=>x.id===cid);return{c,n:c?.notes.find(x=>x.id===nid)}}

function render(){
 normalize();
 const board=document.getElementById('board'); board.innerHTML='';
 state.forEach(c=>{
  const s=document.createElement('section'); s.className='column'; s.dataset.cid=c.id;
  s.innerHTML=`<div class="colhead"><div class="col-drag" title="Arraste para reposicionar">⠿</div><div class="coltitle" title="Duplo clique para editar">${esc(c.title)}</div><button class="headbtn edit" title="Editar quadrante">✎</button><button class="headbtn del" title="Excluir quadrante">×</button></div><div class="notes"></div>`;
  const z=s.querySelector('.notes'); c.notes.forEach(n=>z.appendChild(renderNote(n,c))); bindDrop(z,c.id);
  s.querySelector('.edit').onclick=()=>editColumn(c.id);
  s.querySelector('.coltitle').ondblclick=()=>editColumn(c.id);
  s.querySelector('.del').onclick=()=>deleteColumnModal(c.id);
  bindColumnDrag(s,c.id); board.appendChild(s);
 });
 updateBoardLayout(); applyFilters();
}
function renderNote(n,c){
 const d=document.createElement('article'); d.className='note'; d.draggable=true; d.dataset.id=n.id; d.dataset.status=c.status; d.style.background=c.color;
 const media=n.images?.length?`<div class="note-media">${n.images.slice(0,4).map(x=>`<img src="${x.data}" alt="">`).join('')}</div>`:'';
 const link=n.url?`<a class="note-link" href="${esc(n.url)}" target="_blank" rel="noopener">${esc(n.url)}</a>`:'';
 const trashBtn=c.status==='delivered'?'<button class="trash" title="Enviar para a lixeira">🗑</button>':'';
 d.innerHTML=`<div class="note-actions"><button class="edit" title="Editar">✎</button>${trashBtn}<button class="del" title="Excluir">×</button></div><h3>${esc(n.title)}</h3><p>${esc(n.text)}</p>${media}${link}<div class="meta">Criado em ${date(n.createdAt)}</div>`;
 d.ondragstart=e=>{e.dataTransfer.setData('text/plain',JSON.stringify({type:'note',nid:n.id,from:c.id}));d.classList.add('dragging')};
 d.ondragend=()=>d.classList.remove('dragging');
 d.querySelector('.edit').onclick=e=>{e.stopPropagation();openNoteModal(c.id,n.id)};
 d.querySelector('.del').onclick=e=>{e.stopPropagation();deleteNoteModal(c.id,n.id)};
 d.querySelector('.trash')?.addEventListener('click',e=>{e.stopPropagation();confirmTrashNote(c.id,n.id)});
 return d;
}
function after(z,y){return[...z.querySelectorAll('.note:not(.dragging)')].reduce((best,e)=>{const r=e.getBoundingClientRect(),o=y-r.top-r.height/2;return o<0&&o>best.o?{o,e}:best},{o:-Infinity,e:null}).e}
function bindDrop(z,toid){
 z.ondragover=e=>{e.preventDefault();z.classList.add('dragover');const d=document.querySelector('.dragging');if(d){const a=after(z,e.clientY);a?z.insertBefore(d,a):z.appendChild(d)}};
 z.ondragleave=()=>z.classList.remove('dragover');
 z.ondrop=e=>{e.preventDefault();z.classList.remove('dragover');let q;try{q=JSON.parse(e.dataTransfer.getData('text/plain'))}catch(_){return}
 const from=state.find(c=>c.id===q.from),to=state.find(c=>c.id===toid),n=from?.notes.find(x=>x.id===q.nid);if(!from||!to||!n)return;
 const order=[...z.querySelectorAll('.note')].map(x=>x.dataset.id);from.notes=from.notes.filter(x=>x.id!==q.nid);n.color=to.color;
 if(from.id!==to.id){if(to.status==='delivered'){n.deliveredAt=new Date().toISOString();n.deliveryDue=addBusinessDaysISO(new Date(),1)}else{delete n.deliveredAt;delete n.deliveryDue}to.notes.push(n)}
 const map=new Map(to.notes.map(x=>[x.id,x]));to.notes=order.map(id=>map.get(id)).filter(Boolean);if(!to.notes.some(x=>x.id===n.id))to.notes.push(n);
 render();persist();processDeliveredTimers();if(to.status==='delivered')toast('Tarefa entregue. A lixeira será acionada após 1 dia útil.');
 }
}
function updateBoardLayout(){
 const board=document.getElementById('board'); if(!board)return;
 const count=state.length;
 board.classList.toggle('qf-compact',count<=4);
 board.classList.toggle('qf-scroll',count>=5);
 requestAnimationFrame(updateNav);
}
function updateNav(){
 const b=document.getElementById('board'),l=document.getElementById('navLeft'),r=document.getElementById('navRight'); if(!b||!l||!r)return;
 const max=Math.max(0,b.scrollWidth-b.clientWidth),overflow=max>2;
 l.style.visibility=overflow?'visible':'hidden'; r.style.visibility=overflow?'visible':'hidden';
 l.disabled=!overflow||b.scrollLeft<=2; r.disabled=!overflow||b.scrollLeft>=max-2;
}
function scrollBoard(dir){
 const b=document.getElementById('board'); if(!b)return;
 const col=b.querySelector('.column'); const step=(col?.getBoundingClientRect().width||310)+14;
 b.scrollBy({left:dir*step,behavior:'smooth'});
}

function openNoteModal(cid,nid){
 const {c,n}=noteBy(cid,nid);selectedImages=(n?.images||[]).map(x=>({...x}));
 showModal(`<h2>${n?'Editar post-it':'Novo post-it'}</h2>
 <div class="field"><label>Título</label><input id="noteTitle" maxlength="160" value="${esc(n?.title||'')}"></div>
 <div class="field"><label>Texto</label><textarea id="noteText" maxlength="4000">${esc(n?.text||'')}</textarea></div>
 <div class="field"><label>Imagens</label><div class="attach-row"><input id="noteImages" type="file" accept="image/*" multiple><span style="font-size:12px;color:#727b84">Uma ou mais imagens.</span></div><div id="attachList" class="attach-list"></div></div>
 <div class="field"><label>Link (URL) — opcional</label><input id="noteUrl" type="url" placeholder="https://..." value="${esc(n?.url||'')}"></div>
 <div class="modal-actions"><button class="btn" id="cancelNote" type="button">Cancelar</button><button class="btn primary" id="saveNote" type="button">Salvar</button></div>`);
 renderSelectedImages();
 document.getElementById('cancelNote').addEventListener('click',closeModal);document.getElementById('noteImages').addEventListener('change',handleImages);
 document.getElementById('saveNote').addEventListener('click',()=>{
  const title=document.getElementById('noteTitle').value.trim(),text=document.getElementById('noteText').value.trim();
  if(!title||!text){toast('Preencha título e texto para criar o post-it');return}
  const url=document.getElementById('noteUrl').value.trim();if(url&&!/^https?:\/\//i.test(url)){toast('Use uma URL começando por http:// ou https://');return}
  if(n){n.title=title;n.text=text;n.url=url;n.images=[...selectedImages];n.color=c.color}
  else c.notes.push({id:uid(),title,text,url,images:[...selectedImages],color:c.color,createdAt:new Date().toISOString()});
  closeModal();render();persist()
 })
}
function renderSelectedImages(){const box=document.getElementById('attachList');if(!box)return;box.innerHTML=selectedImages.map((x,i)=>`<div class="attach-item"><img src="${x.data}" alt=""><button type="button" data-i="${i}">×</button></div>`).join('');box.querySelectorAll('button').forEach(b=>b.onclick=()=>{selectedImages.splice(Number(b.dataset.i),1);renderSelectedImages()})}
function handleImages(e){[...e.target.files].forEach(file=>{if(!file.type.startsWith('image/'))return;const r=new FileReader();r.onload=()=>{selectedImages.push({name:file.name,type:file.type,data:r.result});renderSelectedImages()};r.readAsDataURL(file)});e.target.value=''}

function editColumn(id){const c=state.find(x=>x.id===id);if(!c)return;showModal(`<h2>Editar quadrante</h2><div class="field"><label>Nome</label><input id="colName" maxlength="100" value="${esc(c.title)}"></div><div class="modal-actions"><button class="btn" id="cancelCol" type="button">Cancelar</button><button class="btn primary" id="saveCol" type="button">Salvar</button></div>`);document.getElementById('cancelCol').addEventListener('click',closeModal);document.getElementById('saveCol').addEventListener('click',()=>{const v=document.getElementById('colName').value.trim();if(!v){toast('Informe um nome');return}c.title=v;closeModal();render();persist()})}
function deleteColumnModal(id){showModal(`<h2>Excluir quadrante?</h2><p>Você quer mesmo excluir este quadrante e todos os seus post-its?</p><div class="modal-actions"><button class="btn" id="cancelDelete" type="button">Cancelar</button><button class="btn danger" id="yesDelete" type="button">Excluir</button></div>`);document.getElementById('cancelDelete').addEventListener('click',closeModal);document.getElementById('yesDelete').addEventListener('click',()=>{state=state.filter(x=>x.id!==id);closeModal();render();persist();toast('Excluído com sucesso')})}
function deleteNoteModal(cid,nid){showModal(`<h2>Excluir post-it?</h2><p>Você quer mesmo excluir este post-it?</p><div class="modal-actions"><button class="btn" id="cancelDelete" type="button">Cancelar</button><button class="btn danger" id="yesDelete" type="button">Excluir</button></div>`);document.getElementById('cancelDelete').addEventListener('click',closeModal);document.getElementById('yesDelete').addEventListener('click',()=>{const c=state.find(x=>x.id===cid);if(c)c.notes=c.notes.filter(n=>n.id!==nid);closeModal();render();persist();toast('Excluído com sucesso')})}

function bindColumnDrag(el,id){
 el.ondragstart=e=>{ if(e.target.closest('.note')) return; e.stopPropagation(); e.dataTransfer.setData('text/plain',JSON.stringify({type:'column',id})); el.classList.add('column-dragging'); };
 el.ondragend=()=>el.classList.remove('column-dragging');
 el.ondragover=e=>{ const d=e.dataTransfer.getData('text/plain'); if(!d)return; try{const q=JSON.parse(d);if(q.type==='column'){e.preventDefault();e.stopPropagation();el.classList.add('column-target')}}catch(_){} };
 el.ondragleave=()=>el.classList.remove('column-target');
 el.ondrop=e=>{e.preventDefault();e.stopPropagation();el.classList.remove('column-target');let q;try{q=JSON.parse(e.dataTransfer.getData('text/plain'))}catch(_){return}if(q.type!=='column'||q.id===id)return;reorderColumn(q.id,id)};
}
function reorderColumn(fromId,toId){
 const fi=state.findIndex(x=>x.id===fromId),ti=state.findIndex(x=>x.id===toId);if(fi<0||ti<0)return;
 const [item]=state.splice(fi,1);let target=state.findIndex(x=>x.id===toId);
 const first=0,last=state.length-1;
 if(target<=0){target=1} if(target>=state.length){target=state.length-1}
 if(item.status==='todo'||item.status==='delivered'){toast('Os quadrantes Tarefas e Tarefa entregue ficam fixos');state.splice(fi,0,item);return}
 state.splice(target,0,item);render();persist();
}


function confirmTrashNote(cid,nid){
 const {c,n}=noteBy(cid,nid); if(!c||!n)return;
 showModal(`<h2>Enviar para a lixeira?</h2><p>Esta tarefa será enviada para a lixeira. Você poderá restaurá-la depois.</p><div class="modal-actions"><button class="btn" id="cancelTrashNote" type="button">Cancelar</button><button class="btn danger" id="confirmTrashNote" type="button">Enviar para a lixeira</button></div>`);
 document.getElementById('cancelTrashNote').addEventListener('click',closeModal);
 document.getElementById('confirmTrashNote').addEventListener('click',()=>{
   c.notes=c.notes.filter(x=>x.id!==nid);
   trash.push({...n,trashAt:new Date().toISOString(),fromColumnId:c.id,fromColumnTitle:c.title});
   closeModal();render();persist();toast('Enviado para a lixeira');
 });
}
function newColumn(){
 showModal(`<h2>Novo quadrante</h2><div class="field"><label>Nome</label><input id="newColName" maxlength="100" placeholder="Ex.: Aguardando aprovação"></div><div class="modal-actions"><button class="btn" id="cancelNewCol" type="button">Cancelar</button><button class="btn primary" id="createNewCol" type="button">Criar</button></div>`);
 document.getElementById('cancelNewCol').addEventListener('click',closeModal);
 document.getElementById('createNewCol').addEventListener('click',()=>{
  const v=document.getElementById('newColName').value.trim(); if(!v){toast('Informe um nome');return}
  const c={id:uid(),title:v,status:'custom',color:nextUniqueColor(),notes:[]};
  state.splice(Math.max(1,state.length-1),0,c);
  closeModal();render();persist();
  requestAnimationFrame(()=>{updateBoardLayout();const b=document.getElementById('board');b.scrollTo({left:b.scrollWidth,behavior:'smooth'});updateNav()});
 });
}

function processDeliveredTimers(){
 let changed=false,move=[];
 const now=Date.now();
 state.forEach(c=>{if(c.status!=='delivered')return;c.notes.forEach(n=>{if(!n.deliveryDue)n.deliveryDue=addBusinessDaysISO(new Date(n.deliveredAt||Date.now()),1);if(new Date(n.deliveryDue).getTime()<=now)move.push({c,n})})});
 move.forEach(({c,n})=>{c.notes=c.notes.filter(x=>x.id!==n.id);trash.push({...n,trashAt:new Date().toISOString(),fromColumnId:c.id,fromColumnTitle:c.title});changed=true});
 if(changed){persist();render();openDeliveryPopup(move.map(x=>x.n))}
 if(state.some(c=>c.status==='delivered'))setTimeout(processDeliveredTimers,60000)
}
function openDeliveryPopup(items){
 showModal(`<h2>Tarefa entregue</h2><p>${n>1?'As tarefas entregues atingiram o prazo de 1 dia útil e serão enviadas':'A tarefa entregue atingiu o prazo de 1 dia útil e será enviada'} para a lixeira.</p><div class="modal-actions"><button class="btn primary" id="okDelivery" type="button">Entendi</button></div>`);document.getElementById('okDelivery').addEventListener('click',closeModal)
}


function applyFilters(){
 const t=(document.getElementById('filterTitle')?.value||'').trim().toLowerCase(),from=document.getElementById('filterFrom')?.value||'',to=document.getElementById('filterTo')?.value||'';
 document.querySelectorAll('.column').forEach(col=>{const c=state.find(x=>x.id===col.dataset.cid);if(!c)return;c.notes.forEach(n=>{const el=col.querySelector(`[data-id="${CSS.escape(n.id)}"]`);if(!el)return;const d=new Date(n.createdAt).toISOString().slice(0,10);el.style.display=(!t||n.title.toLowerCase().includes(t))&&(!from||d>=from)&&(!to||d<=to)?'':'none'})});updateBoardLayout()
}

function showBoard(){document.getElementById('boardView').style.display='block';document.getElementById('trashPage').classList.remove('show');document.getElementById('detailView').classList.remove('show');requestAnimationFrame(updateBoardLayout)}
function showTrash(){document.getElementById('boardView').style.display='none';document.getElementById('trashPage').classList.add('show');document.getElementById('detailView').classList.remove('show');renderTrash()}
function renderTrash(){const grid=document.getElementById('trashGrid');if(!trash.length){grid.innerHTML='<div class="trash-empty">A lixeira está vazia.</div>';return}grid.innerHTML='<div class="trash-grid">'+trash.slice().reverse().map((n,i)=>`<article class="trash-card" data-i="${trash.length-1-i}"><h3>${esc(n.title)}</h3><p>${esc(n.text)}</p><div class="meta">Enviada para a lixeira em ${date(n.trashAt)}<br>Quadrante: ${esc(n.fromColumnTitle||'Tarefa entregue')}</div></article>`).join('')+'</div>';grid.querySelectorAll('.trash-card').forEach(card=>card.onclick=()=>showTrashDetail(Number(card.dataset.i)))}
function showTrashDetail(index){const n=trash[index];if(!n)return;returnColumnId=n.fromColumnId||null;document.getElementById('boardView').style.display='none';document.getElementById('trashPage').classList.remove('show');document.getElementById('detailView').classList.add('show');document.getElementById('detailCard').innerHTML=`<h2>${esc(n.title)}</h2><div class="meta">Criado em ${date(n.createdAt)} • Enviado para a lixeira em ${date(n.trashAt)}</div><p>${esc(n.text)}</p>${(n.images||[]).length?'<div class="detail-images">'+n.images.map(x=>`<img src="${x.data}" alt="">`).join('')+'</div>':''}${n.url?`<div class="detail-link"><a href="${esc(n.url)}" target="_blank" rel="noopener">${esc(n.url)}</a></div>`:''}`;
  // Ações completas da lixeira são tratadas pela página lixeira.html}
function backFromTrashDetail(){document.getElementById('detailView').classList.remove('show');showBoard();if(returnColumnId)requestAnimationFrame(()=>{const col=document.querySelector(`[data-cid="${CSS.escape(returnColumnId)}"]`);if(col)col.scrollIntoView({behavior:'smooth',block:'nearest',inline:'center'})})}

document.getElementById('addTop').onclick=()=>openNoteModal(state[0]?.id);
document.getElementById('save').onclick=save;document.getElementById('load').onclick=load;document.getElementById('print').onclick=()=>window.print();document.getElementById('trashBtn').onclick=()=>{window.location.href='lixeira.html'};document.getElementById('newcol').onclick=newColumn;document.getElementById('navLeft').onclick=()=>scrollBoard(-1);document.getElementById('navRight').onclick=()=>scrollBoard(1);
const hamburgerQF=document.getElementById('hamburgerQF');
const mobileMenuQF=document.getElementById('mobileMenuQF');
function closeMobileMenu(){if(!mobileMenuQF)return;mobileMenuQF.classList.remove('show');hamburgerQF?.setAttribute('aria-expanded','false');mobileMenuQF.setAttribute('aria-hidden','true')}
hamburgerQF?.addEventListener('click',e=>{e.stopPropagation();const open=!mobileMenuQF.classList.contains('show');mobileMenuQF.classList.toggle('show',open);hamburgerQF.setAttribute('aria-expanded',String(open));mobileMenuQF.setAttribute('aria-hidden',String(!open))});
[['mobileSaveQF','save'],['mobileLoadQF','load'],['mobilePrintQF','print'],['mobileTrashQF','trashBtn'],['mobileNewcolQF','newcol']].forEach(([mid,tid])=>{const a=document.getElementById(mid),b=document.getElementById(tid);if(a&&b)a.addEventListener('click',()=>{b.click();closeMobileMenu()})});
document.addEventListener('click',e=>{if(mobileMenuQF&&!mobileMenuQF.contains(e.target)&&e.target!==hamburgerQF)closeMobileMenu()});
window.addEventListener('resize',()=>{if(window.innerWidth>680)closeMobileMenu()});
document.getElementById('backBoard').onclick=showBoard;document.getElementById('backTrash').onclick=backFromTrashDetail;
document.getElementById('modalBg').addEventListener('click',e=>{if(e.target.id==='modalBg')closeModal()});document.addEventListener('keydown',e=>{if(e.key==='Escape')closeModal()});
window.addEventListener('resize',updateBoardLayout);document.getElementById('board').addEventListener('scroll',updateNav,{passive:true});window.addEventListener('beforeunload',()=>persist());
load();

document.addEventListener('DOMContentLoaded',()=>{
 const b=document.getElementById('board');
 if(!b)return;
 b.addEventListener('wheel',e=>{
   if(Math.abs(e.deltaY)>Math.abs(e.deltaX) && b.scrollWidth>b.clientWidth+2){
     e.preventDefault(); b.scrollLeft += e.deltaY; updateNav();
   }
 },{passive:false});
 b.addEventListener('scroll',updateNav,{passive:true});
 updateBoardLayout();
 setTimeout(updateBoardLayout,100);
});
}
