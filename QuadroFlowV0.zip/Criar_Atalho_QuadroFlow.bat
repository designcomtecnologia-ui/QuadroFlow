@echo off
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0Criar_Atalho_Desktop.ps1"
