#!/bin/sh
DIR="$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)"
xdg-open "$DIR/QuadroFlow.html"
